﻿using System;

namespace InfiniteWhile
{
    class MainApp
    {
        static void Main(string[] args)
        {
            int i = 0;
            while (true)
                Console.WriteLine(i++);
        }
    }
}