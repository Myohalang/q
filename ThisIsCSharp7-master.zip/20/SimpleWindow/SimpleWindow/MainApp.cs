﻿using System;

namespace SimpleWindow
{
    class MainApp : System.Windows.Forms.Form
    {
        static void Main(string[] args)
        {
            System.Windows.Forms.Application.Run(new MainApp());
        }
    }
}
