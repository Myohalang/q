﻿using System;

namespace Constant
{
    class MainApp
    {
        static void Main(string[] args)
        {
            const int a = 3;
            a = 4;
        }
    }
}