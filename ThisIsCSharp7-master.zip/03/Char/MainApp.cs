using System; 
 
namespace Char 
{ 
    class MainApp 
    { 
        static void Main(string[] args) 
        { 
            char a = '��'; 
            char b = '��'; 
            char c = '��'; 
            char d = '��'; 
            char e = '��'; 
 
            Console.Write(a); 
            Console.Write(b); 
            Console.Write(c); 
            Console.Write(d); 
            Console.Write(e); 
            Console.WriteLine(); 
        } 
    } 
} 
