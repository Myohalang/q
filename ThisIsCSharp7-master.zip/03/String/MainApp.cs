using System; 
 
namespace String 
{ 
    class MainApp 
    { 
        static void Main(string[] args) 
        { 
            string a = "�ȳ��ϼ���?"; 
            string b = "�ڻ����Դϴ�."; 
 
            Console.WriteLine(a); 
            Console.WriteLine(b);                 
        } 
    } 
} 
