﻿namespace RoadBook.CsharpBasic.Chapter06.Examples
{
    public class Ex003
    {
        public void Run()
        {
            string[] weathers = new string[7];

            weathers[0] = "sunny";
            weathers[6] = "sunny";
            weathers[7] = "new!!";
        }
    }
}