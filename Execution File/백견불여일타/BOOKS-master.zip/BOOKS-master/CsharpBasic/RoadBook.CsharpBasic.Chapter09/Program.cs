﻿namespace RoadBook.CsharpBasic.Chapter09
{
    class Program
    {
        static void Main(string[] args)
        {
            Examples.Ex001 ex = new Examples.Ex001();

            ex.Run();
        }
    }
}