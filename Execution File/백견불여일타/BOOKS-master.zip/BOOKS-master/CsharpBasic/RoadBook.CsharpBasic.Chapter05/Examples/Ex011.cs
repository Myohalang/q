﻿using RoadBook.CsharpBasic.Chapter05.Examples.Model;

namespace RoadBook.CsharpBasic.Chapter05.Examples
{
    public class Ex011
    {
        public void Run()
        {
            Board board001 = new Board();
            Board board002 = new Board();
            Board board003 = new Board();
            Board board004 = new Board();
            Board board005 = new Board();
        }
    }
}