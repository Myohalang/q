﻿using System;

namespace RoadBook.CsharpBasic.Chapter01.Examples
{
    public class Hello
    {
        public void Run()
        {
            Console.WriteLine("Hello World");
        }
    }
}
