﻿using System; 

namespace RoadBook.CsharpBasic.Chapter02.Examples
{
    public class Ex002
    {
        public void Run()
        {
            char ch = 'A';
            string strMessage = "Hello World";

            Console.WriteLine(ch);
            Console.WriteLine(strMessage);
        }
    }
}