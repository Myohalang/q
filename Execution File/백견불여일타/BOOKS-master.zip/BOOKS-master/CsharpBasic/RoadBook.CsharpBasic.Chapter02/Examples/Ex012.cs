﻿using System; 

namespace RoadBook.CsharpBasic.Chapter02.Examples
{
    public class Ex012
    {
        const float _PIE_VALUE = 3.14f;

        public void Run()
        {
            Console.WriteLine("파이는 {0}", _PIE_VALUE);
        }
    }
}