﻿using System;

namespace RoadBook.CsharpBasic.Chapter04.Examples
{
    public class Ex004
    {
        public void Run()
        {
            int number = 10;

            Console.WriteLine(number++);
            Console.WriteLine(++number);
        }
    }
}