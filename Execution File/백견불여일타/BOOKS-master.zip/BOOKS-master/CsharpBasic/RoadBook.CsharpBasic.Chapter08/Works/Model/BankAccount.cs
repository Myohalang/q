﻿namespace RoadBook.CsharpBasic.Chapter08.Works.Model
{
    public class BankAccount
    {
        public string PrimaryName { get; set; }
        public string UserName { get; set; }
        public int Money { get; set; }
    }
}