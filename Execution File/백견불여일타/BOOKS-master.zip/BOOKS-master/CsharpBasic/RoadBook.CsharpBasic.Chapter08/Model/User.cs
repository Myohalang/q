﻿namespace RoadBook.CsharpBasic.Chapter08.Model
{
    public class User
    {
        public string userID { get; set; }
        public string Name { get; set; }
        public int Age { get; set; }
        public string Job { get; set; }
    }
}