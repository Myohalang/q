﻿namespace RoadBook.CsharpBasic.Chapter10.Examples.Model
{
    public class DatabaseInfo
    {
        public string Ip { get; set; }
        public int Port { get; set; }
        public string Name { get; set; }
        public string UserId { get; set; }
        public string UserPassword{ get; set; }
    }
}