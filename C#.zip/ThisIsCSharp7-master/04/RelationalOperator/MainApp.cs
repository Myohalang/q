﻿using System;

namespace RelationalOperator
{
    class MainApp
    {
        static void Main(string[] args)
        {
            Console.WriteLine($"3 > 4  : {3 > 4}");
            Console.WriteLine($"3 >= 4 : {3 >= 4}");
            Console.WriteLine($"3 < 4  : {3 < 4}");
            Console.WriteLine($"3 <= 4 : {3 <= 4}");
            Console.WriteLine($"3 == 4 : {3 == 4}");
            Console.WriteLine($"3 != 4 : {3 != 4}");
        }
    }
}
