﻿using static System.Console;

namespace MyFirstApp
{
    class Program
    {
        static void Main()
        {
            WriteLine("Hello World");
            ReadKey();
        }
    }
}
