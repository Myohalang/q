﻿using static System.Console;

namespace RoadBook.CsharpBasic.Chapter02.Examples
{
    class Ex002
    {
        public void Run()
        {
            char ch = 'A';
            string strMessage = "hello World";

            WriteLine(ch);
            WriteLine(strMessage);
        }
    }
}
