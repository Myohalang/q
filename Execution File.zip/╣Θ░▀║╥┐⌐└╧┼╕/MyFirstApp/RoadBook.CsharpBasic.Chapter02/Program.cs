﻿using static System.Console;

namespace RoadBook.CsharpBasic.Chapter02
{
    class Program
    {
        static void Main()
        {
            Examples.Ex006 ex001 = new Examples.Ex006();
            ex001.Run();
        }
    }
}
