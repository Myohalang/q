﻿using static System.Console;

namespace RoadBook.CsharpBasic.Chapter01.Examples
{
    public class Hello
    {
        public void Run()
        {
            WriteLine("Hello World");
        }
    }
}
