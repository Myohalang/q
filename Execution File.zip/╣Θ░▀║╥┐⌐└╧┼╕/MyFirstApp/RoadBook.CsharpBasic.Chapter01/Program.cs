﻿namespace RoadBook.CsharpBasic.Chapter01
{
    class Program
    {
        static void Main()
        {
            Examples.Hello hello = new Examples.Hello();
            hello.Run();
        }
    }
}
